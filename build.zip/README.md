# Who's the Fairest Mirror

A mirror that will show who is the fairest from all and the result is always right as yourself is the most fairest. 

## MintBean Mirror Hack

- Using Camera API, Mirror what will show an image of the fairest with filter image.

## Resource:

- [Camera APi](https://developers.google.com/web/updates/2016/12/imagecapture)
- [Typing Effect](https://typeitjs.com/#installation)
- [Mirror Image](https://i.pinimg.com/originals/c0/3b/2c/c03b2cb5cc1e04bbe8dc1763e1ea49d6.png)

## How to Run:

  1. Clone this repository
  2. Open Index.html
  3. Enjoy

## Screenshot:
![](./Digital%20Mirror.gif)